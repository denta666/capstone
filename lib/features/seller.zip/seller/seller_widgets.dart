import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/app_card.dart';
import '../../models/seller_order.dart';

/// Stok sama dengan atau di bawah angka ini dianggap menipis.
const int kLowStock = 10;

class SellerSectionTitle extends StatelessWidget {
  const SellerSectionTitle(
    this.title, {
    super.key,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ),
          if (actionLabel != null)
            TextButton(onPressed: onAction, child: Text(actionLabel!)),
        ],
      ),
    );
  }
}

class SellerStatTile extends StatelessWidget {
  const SellerStatTile({
    super.key,
    required this.icon,
    required this.value,
    required this.label,
    this.accent = false,
    this.onTap,
  });

  final IconData icon;
  final String value;
  final String label;

  /// true = warna peringatan (misalnya stok menipis).
  final bool accent;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final bg = accent ? AppColors.warningSoft : AppColors.primarySoft;
    final fg = accent ? AppColors.warning : AppColors.primary;

    return AppCard(
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
            child: Icon(icon, size: 20, color: fg),
          ),
          const SizedBox(height: 12),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class SellerOrderStatusBadge extends StatelessWidget {
  const SellerOrderStatusBadge(this.status, {super.key});

  final SellerOrderStatus status;

  @override
  Widget build(BuildContext context) {
    final (Color fg, Color bg) = switch (status) {
      SellerOrderStatus.baru => (const Color(0xFF8D6E00), AppColors.warningSoft),
      SellerOrderStatus.diproses => (AppColors.primary, AppColors.primarySoft),
      SellerOrderStatus.dikirim =>
        (AppColors.brownAccent, const Color(0xFFEFE6E2)),
      SellerOrderStatus.selesai => (Colors.white, AppColors.primary),
      SellerOrderStatus.dibatalkan => (AppColors.danger, AppColors.dangerSoft),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.label,
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg),
      ),
    );
  }
}