import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/app_card.dart';
import '../../core/widgets/app_image.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/quantity_stepper.dart';
import '../../data/product_repository.dart';
import '../../models/product.dart';
import '../account/auth_controller.dart';
import 'seller_product_form_screen.dart';
import 'seller_widgets.dart';

enum _Filter { semua, aktif, nonaktif, menipis }

const _filterLabels = {
  _Filter.semua: 'Semua',
  _Filter.aktif: 'Aktif',
  _Filter.nonaktif: 'Nonaktif',
  _Filter.menipis: 'Stok menipis',
};

class SellerProductsScreen extends StatefulWidget {
  const SellerProductsScreen({super.key, this.showLowStock = false});

  /// true = langsung buka dengan filter "Stok menipis".
  final bool showLowStock;

  @override
  State<SellerProductsScreen> createState() => _SellerProductsScreenState();
}

class _SellerProductsScreenState extends State<SellerProductsScreen> {
  late _Filter _filter;

  @override
  void initState() {
    super.initState();
    _filter = widget.showLowStock ? _Filter.menipis : _Filter.semua;
  }

  bool _match(Product p) => switch (_filter) {
        _Filter.semua => true,
        _Filter.aktif => p.isActive,
        _Filter.nonaktif => !p.isActive,
        _Filter.menipis => p.stock <= kLowStock,
      };

  void _openForm([Product? p]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SellerProductFormScreen(initial: p)),
    );
  }

  Future<void> _delete(Product p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus produk?'),
        content: Text('"${p.name}" akan dihapus dari daftar produkmu.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      ProductRepository.instance.remove(p.id);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Produk dihapus')));
    }
  }

  Future<void> _setStock(Product p) async {
    final result = await showDialog<int>(
      context: context,
      builder: (_) => _StockDialog(product: p),
    );
    if (result != null) ProductRepository.instance.setStock(p.id, result);
  }

  Widget _chip(_Filter f) {
    final selected = _filter == f;
    return ChoiceChip(
      label: Text(_filterLabels[f]!),
      selected: selected,
      onSelected: (_) => setState(() => _filter = f),
      showCheckmark: false,
      selectedColor: AppColors.primary,
      backgroundColor: Colors.white,
      shape: const StadiumBorder(),
      side: BorderSide(color: selected ? AppColors.primary : AppColors.border),
      labelStyle: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w600,
        color: selected ? Colors.white : AppColors.textPrimary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final email = AuthController.instance.current?.email ?? '';

    return ListenableBuilder(
      listenable: ProductRepository.instance,
      builder: (context, _) {
        final mine = ProductRepository.instance.ownedBy(email);
        final shown = mine.where(_match).toList();
        final listed = mine.where((p) => p.isListed).length;

        return Scaffold(
          appBar: AppBar(title: const Text('Kelola Produk')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openForm(),
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            icon: const Icon(Icons.add_rounded),
            label: const Text('Tambah Produk'),
          ),
          body: mine.isEmpty
              ? EmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'Belum ada produk',
                  message:
                      'Tambahkan produk pertamamu supaya bisa tampil di marketplace.',
                  actionLabel: 'Tambah produk',
                  onAction: () => _openForm(),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 96),
                  children: [
                    Text(
                      '${mine.length} produk • $listed tampil di marketplace',
                      style: const TextStyle(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 40,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          for (final f in _Filter.values) ...[
                            _chip(f),
                            const SizedBox(width: 8),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (shown.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 48),
                        child: Center(
                          child: Text(
                            'Tidak ada produk pada filter ini.',
                            style: TextStyle(color: AppColors.textSecondary),
                          ),
                        ),
                      )
                    else
                      for (final p in shown) ...[
                        _ProductTile(
                          product: p,
                          onEdit: () => _openForm(p),
                          onDelete: () => _delete(p),
                          onSetStock: () => _setStock(p),
                          onDecrement: p.stock <= 0
                              ? null
                              : () => ProductRepository.instance
                                  .setStock(p.id, p.stock - 1),
                          onIncrement: () => ProductRepository.instance
                              .setStock(p.id, p.stock + 1),
                          onToggle: (v) =>
                              ProductRepository.instance.setActive(p.id, v),
                        ),
                        const SizedBox(height: 12),
                      ],
                    const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text(
                        'Produk nonaktif atau berstok 0 tidak tampil di marketplace. Foto produk ditambahkan saat integrasi.',
                        style: TextStyle(
                          fontSize: 11,
                          height: 1.4,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
        );
      },
    );
  }
}

// ======================= Komponen lokal =======================

class _Tag extends StatelessWidget {
  const _Tag(this.text, {this.fg, this.bg});

  final String text;
  final Color? fg;
  final Color? bg;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg ?? AppColors.primarySoft,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w700,
          color: fg ?? AppColors.primary,
        ),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  const _ProductTile({
    required this.product,
    required this.onEdit,
    required this.onDelete,
    required this.onSetStock,
    required this.onDecrement,
    required this.onIncrement,
    required this.onToggle,
  });

  final Product product;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onSetStock;
  final VoidCallback? onDecrement;
  final VoidCallback onIncrement;
  final ValueChanged<bool> onToggle;

  @override
  Widget build(BuildContext context) {
    final p = product;

    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppImage(
                assetPath: p.imagePath,
                icon: p.icon,
                height: 64,
                width: 64,
                radius: 12,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${formatRupiah(p.price)} • ${p.unit}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _Tag(p.category),
                        if (p.stock == 0)
                          const _Tag(
                            'Stok habis',
                            fg: AppColors.danger,
                            bg: AppColors.dangerSoft,
                          )
                        else if (p.stock <= kLowStock)
                          const _Tag(
                            'Stok menipis',
                            fg: Color(0xFF8D6E00),
                            bg: AppColors.warningSoft,
                          ),
                        if (!p.isActive)
                          const _Tag(
                            'Nonaktif',
                            fg: AppColors.textSecondary,
                            bg: Color(0xFFEDEFED),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Divider(height: 22),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Stok',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              QuantityStepper(
                value: p.stock,
                onDecrement: onDecrement,
                onIncrement: onIncrement,
              ),
              TextButton(onPressed: onSetStock, child: const Text('Atur')),
            ],
          ),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Tampil di marketplace',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              Switch(value: p.isActive, onChanged: onToggle),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                onPressed: onEdit,
                icon: const Icon(Icons.edit_outlined, size: 18),
                label: const Text('Ubah'),
              ),
              TextButton.icon(
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline_rounded, size: 18),
                label: const Text('Hapus'),
                style: TextButton.styleFrom(foregroundColor: AppColors.danger),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StockDialog extends StatefulWidget {
  const _StockDialog({required this.product});

  final Product product;

  @override
  State<_StockDialog> createState() => _StockDialogState();
}

class _StockDialogState extends State<_StockDialog> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: '${widget.product.stock}');
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _save() {
    final n = int.tryParse(_c.text.trim());
    if (n == null) return;
    Navigator.pop(context, n);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Atur stok'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.product.name,
            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _c,
            autofocus: true,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(6),
            ],
            onSubmitted: (_) => _save(),
            decoration: const InputDecoration(
              labelText: 'Jumlah stok',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Batal'),
        ),
        FilledButton(onPressed: _save, child: const Text('Simpan')),
      ],
    );
  }
}