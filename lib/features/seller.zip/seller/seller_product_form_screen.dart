import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/input_style.dart';
import '../../core/widgets/primary_button.dart';
import '../../data/dummy_data.dart';
import '../../data/product_repository.dart';
import '../../models/product.dart';
import '../account/auth_controller.dart';

class SellerProductFormScreen extends StatefulWidget {
  const SellerProductFormScreen({super.key, this.initial});

  /// Kalau diisi, form masuk mode ubah.
  final Product? initial;

  @override
  State<SellerProductFormScreen> createState() =>
      _SellerProductFormScreenState();
}

class _SellerProductFormScreenState extends State<SellerProductFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _name;
  late final TextEditingController _price;
  late final TextEditingController _unit;
  late final TextEditingController _stock;
  late final TextEditingController _location;
  late final TextEditingController _desc;
  late String _category;
  late bool _active;

  bool get _isEdit => widget.initial != null;

  @override
  void initState() {
    super.initState();
    final p = widget.initial;
    _name = TextEditingController(text: p?.name ?? '');
    _price = TextEditingController(text: p == null ? '' : '${p.price}');
    _unit = TextEditingController(text: p?.unit ?? '');
    _stock = TextEditingController(text: p == null ? '' : '${p.stock}');
    _location = TextEditingController(text: p?.location ?? '');
    _desc = TextEditingController(text: p?.description ?? '');
    _category = p?.category ?? DummyData.categories.first.name;
    _active = p?.isActive ?? true;
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    _unit.dispose();
    _stock.dispose();
    _location.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final user = AuthController.instance.current;
    if (user == null) return;

    final repo = ProductRepository.instance;
    final icon = DummyData.categories
        .firstWhere(
          (c) => c.name == _category,
          orElse: () => DummyData.categories.first,
        )
        .icon;
    final price = int.parse(_price.text.trim());
    final stock = int.parse(_stock.text.trim());
    final initial = widget.initial;

    if (initial == null) {
      repo.add(
        Product(
          id: repo.newId(),
          name: _name.text.trim(),
          category: _category,
          price: price,
          unit: _unit.text.trim(),
          rating: 0,
          reviews: 0,
          stock: stock,
          seller: user.name,
          location: _location.text.trim(),
          description: _desc.text.trim(),
          icon: icon,
          ownerEmail: user.email,
          isActive: _active,
        ),
      );
    } else {
      repo.update(
        initial.copyWith(
          name: _name.text.trim(),
          category: _category,
          price: price,
          unit: _unit.text.trim(),
          stock: stock,
          location: _location.text.trim(),
          description: _desc.text.trim(),
          icon: icon,
          isActive: _active,
        ),
      );
    }

    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).pop();
    messenger.showSnackBar(
      SnackBar(
        content: Text(_isEdit ? 'Produk diperbarui' : 'Produk ditambahkan'),
      ),
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Ubah Produk' : 'Tambah Produk')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          children: [
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.sentences,
              decoration: appInputDecoration(
                'Nama produk',
                hint: 'Contoh: Kompos Organik Premium',
              ),
              validator: (v) => (v == null || v.trim().length < 3)
                  ? 'Isi nama produk (minimal 3 huruf)'
                  : null,
            ),
            const SizedBox(height: 18),

            _label('Kategori'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in DummyData.categories)
                  ChoiceChip(
                    label: Text(c.name),
                    selected: _category == c.name,
                    onSelected: (_) => setState(() => _category = c.name),
                    showCheckmark: false,
                    selectedColor: AppColors.primary,
                    backgroundColor: Colors.white,
                    shape: const StadiumBorder(),
                    side: BorderSide(
                      color: _category == c.name
                          ? AppColors.primary
                          : AppColors.border,
                    ),
                    labelStyle: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: _category == c.name
                          ? Colors.white
                          : AppColors.textPrimary,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 18),

            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _price,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(9),
                    ],
                    decoration: appInputDecoration('Harga', hint: 'Rp'),
                    validator: (v) {
                      final n = int.tryParse((v ?? '').trim());
                      if (n == null || n <= 0) return 'Isi harga > 0';
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _stock,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(6),
                    ],
                    decoration: appInputDecoration('Stok'),
                    validator: (v) {
                      final n = int.tryParse((v ?? '').trim());
                      if (n == null) return 'Isi stok (boleh 0)';
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _unit,
              decoration: appInputDecoration(
                'Satuan / ukuran kemasan',
                hint: 'Contoh: karung 5 kg',
              ),
              validator: (v) => (v == null || v.trim().isEmpty)
                  ? 'Isi satuan atau ukuran kemasan'
                  : null,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _location,
              textCapitalization: TextCapitalization.words,
              decoration: appInputDecoration(
                'Lokasi penjual',
                hint: 'Contoh: Kab. Tegal',
              ),
              validator: (v) => (v == null || v.trim().isEmpty)
                  ? 'Isi lokasi penjual'
                  : null,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _desc,
              minLines: 3,
              maxLines: 6,
              textCapitalization: TextCapitalization.sentences,
              decoration: appInputDecoration(
                'Deskripsi',
                hint: 'Jelaskan produkmu dengan jujur dan jelas',
              ),
              validator: (v) => (v == null || v.trim().length < 10)
                  ? 'Deskripsi minimal 10 karakter'
                  : null,
            ),
            const SizedBox(height: 14),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Tampilkan di marketplace',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          'Produk berstok 0 tetap disembunyikan',
                          style: TextStyle(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: _active,
                    onChanged: (v) => setState(() => _active = v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Foto produk ditambahkan saat integrasi. Untuk sekarang produk memakai gambar placeholder. Rating dan ulasan mulai dari 0.',
              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: PrimaryButton(
              label: _isEdit ? 'Simpan Perubahan' : 'Tambah Produk',
              icon: Icons.check_rounded,
              onPressed: _save,
            ),
          ),
        ),
      ),
    );
  }
}