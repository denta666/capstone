import 'package:flutter/foundation.dart';
import '../../models/seller_order.dart';
import '../account/auth_controller.dart';

DateTime _daysAgo(int days, {int hour = 10}) {
  final n = DateTime.now();
  return DateTime(n.year, n.month, n.day, hour).subtract(Duration(days: days));
}

SellerOrderLine _kompos(int q) => SellerOrderLine(
    name: 'Kompos Organik Premium', unit: 'karung 5 kg', qty: q, price: 45000);

SellerOrderLine _maggotFresh(int q) => SellerOrderLine(
    name: 'Maggot BSF Fresh', unit: 'kemasan 1 kg', qty: q, price: 28000);

SellerOrderLine _maggotKering(int q) => SellerOrderLine(
    name: 'Maggot BSF Kering', unit: 'kemasan 500 g', qty: q, price: 55000);

SellerOrderLine _kasgot(int q) => SellerOrderLine(
    name: 'Kasgot (Sisa Maggot)', unit: 'karung 5 kg', qty: q, price: 30000);

/// Pesanan masuk penjual (lokal, di memori). SEMUA data awal adalah CONTOH
/// demo milik akun penjual demo, bukan transaksi sungguhan.
class SellerOrderController extends ChangeNotifier {
  SellerOrderController._() {
    _orders.addAll(_seed());
  }

  static final SellerOrderController instance = SellerOrderController._();

  final List<SellerOrder> _orders = [];

  static List<SellerOrder> _seed() {
    const email = AuthController.demoSellerEmail;
    return [
      SellerOrder(
        id: 'PS-0001',
        sellerEmail: email,
        buyerName: 'Rina Wulandari',
        buyerCity: 'Kab. Tegal',
        date: _daysAgo(0, hour: 9),
        shipping: 10000,
        status: SellerOrderStatus.baru,
        lines: [_kompos(2)],
      ),
      SellerOrder(
        id: 'PS-0002',
        sellerEmail: email,
        buyerName: 'Budi Santoso',
        buyerCity: 'Kota Semarang',
        date: _daysAgo(1, hour: 14),
        shipping: 12000,
        status: SellerOrderStatus.baru,
        lines: [_maggotFresh(3)],
      ),
      SellerOrder(
        id: 'PS-0003',
        sellerEmail: email,
        buyerName: 'Siti Aminah',
        buyerCity: 'Kab. Brebes',
        date: _daysAgo(2, hour: 11),
        shipping: 10000,
        status: SellerOrderStatus.diproses,
        lines: [_kasgot(2), _kompos(1)],
      ),
      SellerOrder(
        id: 'PS-0004',
        sellerEmail: email,
        buyerName: 'Agus Pratama',
        buyerCity: 'Kota Tegal',
        date: _daysAgo(3, hour: 10),
        shipping: 8000,
        status: SellerOrderStatus.dikirim,
        lines: [_maggotKering(1)],
      ),
      SellerOrder(
        id: 'PS-0005',
        sellerEmail: email,
        buyerName: 'Dewi Lestari',
        buyerCity: 'Kota Bandung',
        date: _daysAgo(5, hour: 15),
        shipping: 20000,
        status: SellerOrderStatus.selesai,
        lines: [_kompos(3)],
      ),
      SellerOrder(
        id: 'PS-0006',
        sellerEmail: email,
        buyerName: 'Hendra Kurniawan',
        buyerCity: 'Kab. Pemalang',
        date: _daysAgo(8, hour: 9),
        shipping: 10000,
        status: SellerOrderStatus.selesai,
        lines: [_maggotFresh(2), _maggotKering(1)],
      ),
      SellerOrder(
        id: 'PS-0007',
        sellerEmail: email,
        buyerName: 'Nurul Hidayah',
        buyerCity: 'Kota Pekalongan',
        date: _daysAgo(12, hour: 13),
        shipping: 12000,
        status: SellerOrderStatus.selesai,
        lines: [_kasgot(4)],
      ),
      SellerOrder(
        id: 'PS-0008',
        sellerEmail: email,
        buyerName: 'Rizky Maulana',
        buyerCity: 'Kota Semarang',
        date: _daysAgo(16, hour: 10),
        shipping: 12000,
        status: SellerOrderStatus.dibatalkan,
        lines: [_kompos(2)],
      ),
      SellerOrder(
        id: 'PS-0009',
        sellerEmail: email,
        buyerName: 'Putri Ayu',
        buyerCity: 'Kab. Tegal',
        date: _daysAgo(20, hour: 16),
        shipping: 10000,
        status: SellerOrderStatus.selesai,
        lines: [_maggotFresh(5)],
      ),
      SellerOrder(
        id: 'PS-0010',
        sellerEmail: email,
        buyerName: 'Fajar Nugroho',
        buyerCity: 'Kab. Brebes',
        date: _daysAgo(25, hour: 11),
        shipping: 10000,
        status: SellerOrderStatus.selesai,
        lines: [_kompos(4)],
      ),
    ];
  }

  /// Terbaru di atas.
  List<SellerOrder> forSeller(String email) {
    final list = _orders.where((o) => o.sellerEmail == email).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  SellerOrder? byId(String id) {
    for (final o in _orders) {
      if (o.id == id) return o;
    }
    return null;
  }

  void updateStatus(String id, SellerOrderStatus status) {
    final i = _orders.indexWhere((o) => o.id == id);
    if (i < 0) return;
    _orders[i] = _orders[i].copyWith(status: status);
    notifyListeners();
  }
}